int quux() { return 42; }
