#include "examples/test_cc_shared_library/preloaded_dep.h"

int preloaded_dep() { return 42; }
